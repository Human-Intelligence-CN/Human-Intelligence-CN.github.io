#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define LENGTH 30
int d1();/*d for Determinant, number for order*/
int d2();
int d3();
int d4();
int cal();/*regular calculate*/
int inv();/*invertion*/
int main(){
	int dp, e = 1;/*dp=display, e=exit*/
	char com;/*com=command*/
	printf("Detcom [version 1.2.1.14]\n");
	printf("(c)harukaworks.link all rights reserved.\n\n");
	printf("> ");
	while (e == 1){
		scanf("%c", &com);
		switch (com) {/*determine order of the determinant*/
			case 49:/*command '1' for 1-order-det*/
				dp = d1();
				printf("%d\n", dp);
				printf("> ");
				break;
			case 50:/*command '2' for 2-order-det*/
				dp = d2();
				printf("%d\n", dp);
				printf("> ");
				break;
			case 51:/*command '3' for 3-order-det*/
				dp = d3();
				printf("%d\n", dp);
				printf("> ");
				break;
			case 52:/*command '4' for 4-order-det*/
				dp = d4();
				printf("%d\n", dp);
				printf("> ");
				break;
			case 63:/*command '?' for help*/
				printf("num ----/Insert num-order-Det.\n");
				printf("e   ----/Exit.\n");
				printf("c   ----/Clear screen.\n");
				printf("f   ----/Regular calculate.\n");
				printf("i   ----/Inversions.\n");
				printf("?   ----/help.\n");
				printf("!You may incert in either UPPER CASE or lower case.\n");
				printf("-'f' help for calculate mode\n");
				printf("+ num1 method num2\n");
				printf("+- method\n");
				printf(" + '+'----/Plus.\n");
				printf(" + '-'----/Minus.\n");
				printf(" + '*'----/Times.\n");
				printf(" + '/'----/Divide by.\n");
				printf(" + '^'----/Powers.\n");
				printf("> ");
				break;
			case 67:/*command 'C' for clear screen*/
				system("cls");
				printf("> ");
				break;
			case 69:/*command 'E' for exit*/
				e = 0;
				break;
			case 70:/*command 'F' for calculate*/
				dp = cal();
				printf("Calculate mode disabled.\n");
				printf("> ");
				break;
			case 73:/*command 'I' for inversions*/
				dp = inv();
				printf("> ");
				break;
			case 99:/*command 'c' for clear screen*/
				system("cls");
				printf("> ");
				break;
			case 101:/*command 'e' for exit*/
				e = 0;
				break;
			case 102:/*command 'f' for calculate*/
				dp = cal();
				printf("Calculate mode disabled.\n");
				printf("> ");
				break;
			case 105:/*command 'i' for inversions*/
				dp = inv();
				printf("> ");
				break;
		}
	}
	return 0;
}
int d1(){
	int q;
	printf("You are calculating a 1-order-Det.\n");
	printf("Insert your first line.\n");
	printf("> ");
	scanf("%d", &q);
	return q;
}
int d2(){
	int a1, b1, a2, b2, q;
	printf("You are calculating a 2-order-Det.\n");
	printf("Insert your first line.\n");
	printf("> ");
	scanf("%d %d", &a1, &b1);
	printf("Insert your second line.\n");
	printf("> ");
	scanf("%d %d", &a2, &b2);
	q = a1*b2-a2*b1;
	return q;
}
int d3(){
	int a1, b1, c1, a2, b2, c2, a3, b3, c3, q;
	printf("You are calculating a 3-order-Det.\n");
	printf("Insert your first line.\n");
	printf("> ");
	scanf("%d %d %d", &a1, &b1, &c1);
	printf("Insert your second line.\n");
	printf("> ");
	scanf("%d %d %d", &a2, &b2, &c2);
	printf("Insert your third line.\n");
	printf("> ");
	scanf("%d %d %d", &a3, &b3, &c3);
	q = a1 * b2 * c3 + a2 * b3 * c1 + a3 * b1 * c2 - a1 * b3 * c2 - a2 * b1 * c3 - a3 * b2 * c1;
	return q;
}
int d4(){
	int a1, b1, c1, d1, a2, b2, c2, d2, a3, b3, c3, d3, a4, b4, c4, d4, q;
	printf("You are calculating a 4-order-Det.\n");
	printf("Insert your first line.\n");
	printf("> ");
	scanf("%d %d %d %d", &a1, &b1, &c1, &d1);
	printf("Insert your second line.\n");
	printf("> ");
	scanf("%d %d %d %d", &a2, &b2, &c2, &d2);
	printf("Insert your third line.\n");
	printf("> ");
	scanf("%d %d %d %d", &a3, &b3, &c3, &d3);
	printf("Insert your fourth line.\n");
	printf("> ");
	scanf("%d %d %d %d", &a4, &b4, &c4, &d4);
	q = a1 * (b2 * c3 * d4 + c2 * d3 * b4 + d2 * b3 * c4 - d2 * c3 * b4 - c2 * b3 * d4 - b2 * d3 * c4) - a2 * (b1 * c3 * d4 + c1 * d3 * b4 + d1 * b3 * c4 - d1 * c3 * b4 - c1 * b3 * d4 - b1 * d3 * c4) + a3 * (b1 * c2 * d4 + c1 * d2 * b4 + d1 * b2 * c4 - d1 * c2 * b4 - c1 * b2 * d4 - b1 * d2 * c4) - a4 * (b1 * c2 * d3 + c1 * d2 * b3 + d1 * b2 * c3 - d1 * c2 * b3 - c1 * b2 * d3 - b1 * d2 * c3);
	return q;
}
int cal() /*regular calculate*/ {
	double f1, f2, db2;
	char me;
	printf("Calculate mode enabled.\n");
	while (1) {
		printf("Cal> ");
		scanf("%lf %c %lf", &f1, &me, &f2);
		if (me == '+') {
			db2 = f1 + f2;
			printf("%lf\n", db2);
		}
		else if (me == '-'){
			db2 = f1 - f2;
		printf("%lf\n", db2);
		}
		else if (me == '*'){
			db2 = f1 * f2;
			printf("%lf\n", db2);
		}
		else if (me == '/') {
			db2 = f1 / f2;
			printf("%lf\n", db2);
		}
		else if (me == '^') {
			db2 = pow(f1, f2);
			printf("%lf\n", db2);
		}
		else if (me == 'e' || me == 'E')
			break;
	}
	return 0;
}
int inv() /*invertion*/ {
	int in[LENGTH], di, q = 0, i, j, k;
	printf("How many digits are there in the combination?\n> ");
	scanf("%d", &di);
	printf("Insert your combination.\n");
	for (k = 0; k < (di); k++) {
		printf("|> ");
		scanf("%d", &in[k]);
	}
	for (int i = 0; i < di; i++)
	{
		for (int j = i + 1; j < di; j++)
		{
			if (in[i] > in[j])
				q++;
		}
	}
	printf("%d\n", q);
	return 0;
}